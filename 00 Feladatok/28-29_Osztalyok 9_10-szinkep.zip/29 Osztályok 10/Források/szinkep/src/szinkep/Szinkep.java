package szinkep;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * emelt infó érettségi 2012. október
 *
 * @author Tóth József
 */
public class Szinkep {

    static final int MERET = 50;
    static Keppont[][] kep = new Keppont[MERET + 1][MERET + 1];

    static void megjelenit() {
        int i, j;
        for (i = 1; i <= MERET; i++) {
            for (j = 1; j <= MERET; j++) {
                System.out.print(kep[i][j].szinjel());
            }
            System.out.println();
        }
    }

    public static void main(String[] args) throws IOException {
        // beolvasás
        Scanner be = new Scanner(new File("kep.txt"));
        int sor, oszlop;
        for (sor = 1; sor <= MERET; sor++) {
            for (oszlop = 1; oszlop <= MERET; oszlop++) {
                kep[sor][oszlop] = new Keppont(be.nextLine());
            }
        }
        be.close();
        megjelenit();

        // szerepel-e
        Scanner bill = new Scanner(System.in);
        System.out.print("Színkód (200 96 64): ");
        String kod = bill.nextLine();
        boolean van = false;
        for (sor = 1; sor <= MERET; sor++) {
            for (oszlop = 1; oszlop <= MERET; oszlop++) {
                if (kep[sor][oszlop].getSzin().equals(kod)) {
                    van = true;
                    break;
                }
            }
            if (van) {
                break;
            }
        }
        if (van) {
            System.out.println("Van ilyen színű pont.");
        } else {
            System.out.println("Nincs ilyen színű pont.");
        }
    }
}
