package szinhaz;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 * 2014. októberi emelt szintű érettségi feladat
 * @author Tóth József
 */
public class Szinhaz {
    static final int MERET = 15;
    static Szeksor[] nezoter = new Szeksor[MERET];
    
    public static void main(String[] args) throws IOException {
        // Adatok beolvasása
        Scanner be1 = new Scanner(new File("foglaltsag.txt"));
        Scanner be2 = new Scanner(new File("kategoria.txt"));
        for (int i = 0; i < MERET; i++) {
            nezoter[i] = new Szeksor(be1.nextLine(), be2.nextLine());
        }
        be1.close();
        be2.close();
        
        // Foglaltság lekérdezése
        Scanner bill = new Scanner(System.in);
        System.out.print("Sor és székszám: ");
        int sor = bill.nextInt() - 1;
        int szek = bill.nextInt() - 1;
        if (nezoter[sor].szabad(szek)) {
            System.out.println("szabad");
        }
        else {
            System.out.println("foglalt");
        }
    }    
}
