package szinhaz;

/**
 * Egy sor szék adatai (foglalt-e, kategória)
 * @author Tóth József
 */
public class Szeksor {
    private String foglalt;
    private String kategoria;

    public Szeksor(String foglalt, String kategoria) {
        this.foglalt = foglalt;
        this.kategoria = kategoria;
    }

    /**
     * megadja, hogy szabad-e 
     * a kapott indexű szék a sorban
     * @param szek szék indexe
     * @return szabad-e
     */
    public boolean szabad(int szek) {
        return foglalt.charAt(szek) == 'o';
    }
    
    //teszt
    public static void main(String[] args) {
        Szeksor sz1 = new Szeksor("xxoxoxoxoxoxooxxxxox", 
                                  "22222111111111122222"); 
        System.out.println(sz1.szabad(0));
        System.out.println(sz1.szabad(2));
    }
    
}
